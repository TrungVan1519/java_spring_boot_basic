package com.example.Project1_Openning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project1OpenningApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project1OpenningApplication.class, args);
	}

}
