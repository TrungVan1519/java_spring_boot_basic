package com.example.Project1_Openning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1OpenningApplicationTests {

	@Test
	void contextLoads() {
	}

}
